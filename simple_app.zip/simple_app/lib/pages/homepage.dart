import 'package:flutter/material.dart';
import 'package:simple_app/pages/booking.dart';
import 'package:simple_app/pages/login.dart';
import 'package:simple_app/drawer.dart';
import 'package:simple_app/tabs/first.dart';

class Home extends StatefulWidget {
  final String userName;

  Home({this.userName});

  @override
  State<StatefulWidget> createState() {
    return HomePage();
  }
}


class HomePage extends State<Home> {
    final String userName;

    HomePage({this.userName});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        title: Text('Homepage'),
        backgroundColor: new Color(0xFF8B1122),
      ),
          drawer: NavigationDrawer(),
           //drawer
    
      body: new Container(
        
        child: ListView(
          
          children: <Widget>[
            
              Container(
                decoration: new BoxDecoration(color: Colors.blueGrey[50]),
                padding: EdgeInsets.all(10),
                child: Row(
                  children: <Widget>[
                     Container(
                       width: 100.0,
                       height: 100.0,
                       color: Colors.blue,
                       child: new Icon(
                         Icons.home, 
                         color: 
                         Colors.white,
                          size: 50.0,
                          ),
                    
                     ),
                     Expanded(
                       child: Container(
                         padding: EdgeInsets.all(15.0),
                         height: 100.0,
                         color: Colors.grey[400],
                         child: Column(
                           crossAxisAlignment: CrossAxisAlignment.start,
                           children: <Widget>[
                             Text("Sport Hall 2 - UTM", style: TextStyle(color: Colors.black, fontSize: 15.0)),
                             Text("Kolej Tun Fatimah", style: TextStyle(color: Colors.black),),
                          
                           ],
                         ),
                       ),
                     )
                  ],
                ),
                
              ),
              Container(
                padding: EdgeInsets.all(10),
                child: Row(
                  children: <Widget>[
                     Container(
                       width: 100.0,
                       height: 100.0,
                       color: Colors.blue,
                       child: new Icon(Icons.home, color: Colors.white, size: 50.0,),
                     ),
                     Expanded(
                       child: Container(
                         padding: EdgeInsets.all(15.0),
                         height: 100.0,
                         color: Colors.grey[400],
                         child: Column(
                           crossAxisAlignment: CrossAxisAlignment.start,
                           children: <Widget>[
                             Text("SPORT HALL 1", style: TextStyle(color: Colors.black, fontSize: 15.0)),
                             Text("KOLEJ PERDANA", style: TextStyle(color: Colors.black),)
                           ],
                         ),
                       ),
                     )
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                child: Row(
                  children: <Widget>[
                     Container(
                       width: 100.0,
                       height: 100.0,
                       color: Colors.blue,
                       child: new Icon(Icons.home, color: Colors.white, size: 50.0,),
                     ),
                     Expanded(
                       child: Container(
                         padding: EdgeInsets.all(15.0),
                         height: 100.0,
                         color: Colors.grey[400],
                         child: Column(
                           crossAxisAlignment: CrossAxisAlignment.start,
                           children: <Widget>[
                             Text("NETBALL COURT", style: TextStyle(color: Colors.black, fontSize: 15.0)),
                             Text("KOLEJ TUN FATIMAH", style: TextStyle(color: Colors.black),)
                           ],
                         ),
                       ),
                     )
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                child: Row(
                  children: <Widget>[
                     Container(
                       width: 100.0,
                       height: 100.0,
                       color: Colors.blue,
                       child: new Icon(Icons.home, color: Colors.white, size: 50.0,),
                       
                     ),
                     Expanded(
                       child: Container(
                         padding: EdgeInsets.all(15.0),
                         height: 100.0,
                         color: Colors.grey[400],
                         child: Column(
                           crossAxisAlignment: CrossAxisAlignment.start,
                           children: <Widget>[
                             Text("UTM SWIMMING POOL", style: TextStyle(color: Colors.black, fontSize: 15.0)),
                             Text("AZMAN HASHIM", style: TextStyle(color: Colors.black),)
                           ],
                         ),
                       ),
                     )
                  ],
                  
                ),
              ),
          ],
        ),
        
      ),
      
    );
    
 
    Widget headerSection() {
    return Expanded(
      flex: 1,
      child: Card(
        margin: EdgeInsets.all(10.0),
        child: Container(
          width: double.infinity,
          color: Colors.deepOrange,
          padding: EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Hi! ' + widget.userName,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
      
            ],
      ),
        )
      )
    );
      
  }

}
}
